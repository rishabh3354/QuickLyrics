AGENT = "Mozilla/5.0 (Windows NT 6.0; WOW64; rv:24.0) \
        Gecko/20100101 Firefox/24.0"
HEADERS = {"User-Agent": AGENT}
SOURCE = "https://www.azlyrics.com/"
SEARCH_SOURCE = "https://search.azlyrics.com/"
